let ZOMBIE1_x=-100;
let ZOMBIE2_x=-100;
let ZOMBIE3_x=-300;
let mthr_x=200;
let img;

function preload(){
  img = loadImage("ble.png")
  img2 = loadImage("ble1.png")
  img3 = loadImage("ble3.jpeg")
  img4 = loadImage("hoho.png")
}

function setup() {
  createCanvas(900, 900);
  frameRate(50);
}

function draw() {
  background(2);
  
  fill("GREEN");
  strokeWeight(0);
  ellipse(ZOMBIE1_x,290,220,240);
  ellipse(ZOMBIE2_x,290,220,240);
  ellipse(ZOMBIE3_x,290,220,240);
  
  fill("brown");
  rect(0,300,800,300);
  
  fill(247,250,96);
  circle(30,30,40);
  
  image(img, 400, 250, 200, 230)
  image(img2, 350, 300, 200, 230)
  image(img3, 220, 300, 200, 230)
  image(img4, 10, 300, 200, 230)
  
  
  
  ZOMBIE1_x=ZOMBIE1_x+1;
  ZOMBIE2_x=ZOMBIE2_x+1;
  ZOMBIE3_x=ZOMBIE3_x+1;
  if(ZOMBIE1_x>400+200)ZOMBIE1_x=-100;
  if(ZOMBIE2_x>400+200)ZOMBIE2_x=-100;
  if(ZOMBIE3_x>400+200)ZOMBIE3_x=-100;
  
  mthr_x
}